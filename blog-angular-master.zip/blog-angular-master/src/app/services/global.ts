export const global = {
  url: 'http://api-rest-laravel.test/api/',
};
